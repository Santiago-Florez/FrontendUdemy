package controller;

public class Controller {
    
    private final int idController;
    private static int contController;
    
    //Bloque codigo inicializacion para atributos static
//    static{
//        System.out.println("Bloque estatico");
//        ++Controller.contController;
//    }
    //bloque de codigo para atributos no static
    {
        this.idController = ++Controller.contController;
        System.out.println("Bloque no estatico");
    }

    public int getIdController() {
        return this.idController;
    }

    public static int getContController() {
        return contController;
    }

    public static void setContController(int contController) {
        Controller.contController = contController;
    }
}
