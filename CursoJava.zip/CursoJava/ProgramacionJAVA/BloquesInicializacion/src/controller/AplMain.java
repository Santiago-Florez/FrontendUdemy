package controller;

public class AplMain {
    
    public static void main(String[] args) {
        Controller c = new Controller();
        System.out.println(Controller.getContController());
        System.out.println(c.getIdController());
        Controller c2 = new Controller();
        System.out.println(c2.getIdController());
        System.out.println(Controller.getContController());
        Controller c3 = new Controller();
        System.out.println(c3.getIdController());
    }
}
