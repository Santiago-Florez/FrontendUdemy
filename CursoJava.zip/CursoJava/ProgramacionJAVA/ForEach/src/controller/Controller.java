package controller;

public class Controller {
    
    private int edades[];
    
    public Controller(){
        this.edades = new int [2];
        funcionar();
    }
    
    public void funcionar(){
        this.edades[0] = 3;
        this.edades[1] = 7;
        for(int edad: this.edades){
            System.out.println(edad);
        }
    }
}
