package controller;

public enum Continentes {
    
    ASIA(44),
    AMERICA(34),
    EUROPA(46),
    OCEANIA(14),
    AFRICA(53);

    private final int paises;
    
    Continentes(int paises){
        this.paises = paises;
    }
    
    public void pais(){
        System.out.println("this = " + this);
    }
    
    public int getPaises(){
        return this.paises;
    }
}
