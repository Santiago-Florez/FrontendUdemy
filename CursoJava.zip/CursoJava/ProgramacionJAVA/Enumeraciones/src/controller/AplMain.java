package controller;

public class AplMain {

    public static void main(String[] args) {
        indicarDia(Dias.MARTES);
        indicarPais(Continentes.AFRICA);
    }
    
    public static void indicarDia(Dias dias){
        switch(dias){
            case LUNES:
                System.out.println(dias.LUNES);
                break;
            case MARTES:
                System.out.println(dias.MARTES);
                break;
            case MIERCOLES:
                System.out.println(dias.MIERCOLES);
                break;
            case JUEVES:
                System.out.println(dias.JUEVES);
                break;
            case VIERNES:
                System.out.println(dias.VIERNES);
                break;
            case SABADO:
                System.out.println(dias.SABADO);
                break;
            case DOMINGO:
                System.out.println(dias.DOMINGO);
                break;
        }
    }
    
    
    public static void indicarPais(Continentes pais) {
        switch(pais.getPaises()){
            case 53:
                System.out.println("Continente: " + pais.AFRICA + ", paises: " + pais.AFRICA.getPaises());
                pais.pais();
                break;
        }
    }
}
