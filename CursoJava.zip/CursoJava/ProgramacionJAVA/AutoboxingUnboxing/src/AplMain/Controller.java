package AplMain;

public class Controller {
    //Clases Envolventes
    /*
    int - Integer
    long - Long
    float - Float
    double - Double
    booleam - Boolean
    byte - Byte
    char - Character
    short - Short
    */
    
    public void funcionar(){
        Integer entero = 10;//Autoboxing
        //Al ser un objeto de la clase Integer se puede modificar su valor
        double m = 10.0;
        System.out.println(entero + m);
        
        int entero2 = entero;//Unboxing
        System.out.println("entero2 = " + entero2);
    }
}
