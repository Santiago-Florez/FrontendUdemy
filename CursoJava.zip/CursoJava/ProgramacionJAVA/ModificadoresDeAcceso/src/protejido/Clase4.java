package protejido;
/*
el protected se usa mas en el tema de herencia
*/
public class Clase4 extends Clase3{

        public Clase4(){
            super();//llama al constructor de la clase
            int a = this.atributo;//se llama el atributo protegido
            super.metodo();
        }
}
