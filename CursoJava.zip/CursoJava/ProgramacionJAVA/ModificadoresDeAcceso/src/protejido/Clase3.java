package protejido;

public class Clase3 {
    
    protected int atributo;
    
    protected Clase3(){
        this.atributo = 12;
    }
    
    protected void metodo(){
        
    }
}
