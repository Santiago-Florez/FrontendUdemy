package publico;
/*
se puede acceder a todos los datos de la clase1 al tener todo publico
*/
public class Clase2 {

    public Clase1 c;
    
    public Clase2(){
        c = new Clase1();
        int a = c.atributo;
        c.metodo();
    }
}
