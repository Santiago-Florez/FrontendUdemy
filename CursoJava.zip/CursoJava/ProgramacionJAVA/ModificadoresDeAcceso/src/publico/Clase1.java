package publico;

public class Clase1 {
    
    public int atributo;
    
    public Clase1(){
        atributo = 12;
    }
    
    public void metodo(){
        
    }
}
