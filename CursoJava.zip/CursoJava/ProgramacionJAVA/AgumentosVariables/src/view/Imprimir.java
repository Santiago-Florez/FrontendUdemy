package view;

public class Imprimir {
    
    public void imprimir(int... num){
        //el argumento num al declararlo con los 3 puntos hace como si fuera un arreglo
        for (int i = 0; i < num.length; i++) {
            System.out.println(num[i]);
        }
    }
    
    public void imprimir2(String s, int... p){
        System.out.println(s);
        for (int i = 0; i < p.length; i++) {
            System.out.println(p[i]);
        }
    }
}
