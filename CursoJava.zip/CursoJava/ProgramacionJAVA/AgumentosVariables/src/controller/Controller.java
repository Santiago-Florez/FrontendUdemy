package controller;

import view.Imprimir;

public class Controller {
    
    private Imprimir imp;
    
    public Controller(){
        imp = new Imprimir();
        funcionar();
    }
    
    public void funcionar(){
        //se llama al metodo de la clase Imprimir y se le pueden pasar los argumentos que se quieran ya que se pusieron los 3 puntos
        for (int i = 1; i <= 1; i++) {
            //imp.imprimir(i);
            imp.imprimir2("sapo", 1,2,3,4,5,6);
        }
        
    }
    
    
}
