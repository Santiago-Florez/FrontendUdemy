package view;

import javax.swing.JOptionPane;

public class Ventana {
    
    public Ventana(){
        
    }
    
    public void mostrarInformacion(String mensaje){
        JOptionPane.showMessageDialog(null, mensaje);
    }
}
