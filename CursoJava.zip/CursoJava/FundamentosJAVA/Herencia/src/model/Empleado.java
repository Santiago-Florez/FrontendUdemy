package model;

public class Empleado extends Persona{
    
    private double sueldo;
    private int idEmpleado;
    private static int contEmpeleado;

    public Empleado(String nombre, double sueldo) {
        super(nombre);
        this.sueldo = sueldo;
        this.idEmpleado = ++Empleado.contEmpeleado;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Empleado{sueldo =").append(sueldo);
        sb.append(", idEmpleado =").append(idEmpleado);
        sb.append(", Nombre = ").append(this.nombre);
        sb.append('}');
        return sb.toString();
    }

    public double getSueldo() {
        return sueldo;
    }

    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }

    public int getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(int idEmpleado) {
        this.idEmpleado = idEmpleado;
    }      
}
