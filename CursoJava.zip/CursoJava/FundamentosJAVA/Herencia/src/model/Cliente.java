package model;

import java.util.Date;

public class Cliente extends Persona{
    
    private int idCliente;
    private static int contCliente;
    private Date fechaRegistro;
    private boolean vip;
    
    public Cliente(String nombre, Date fechaR, boolean vip){
        super(nombre);
        this.idCliente = ++contCliente;
        this.fechaRegistro = fechaR;
        this.vip = vip;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Cliente{idCliente= ").append(idCliente);
        sb.append(", fechaRegistro= ").append(fechaRegistro);
        sb.append(", vip= ").append(vip);
        sb.append(", Nombre= ").append(this.nombre);
        sb.append('}');
        return sb.toString();
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public Date getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(Date fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public boolean isVip() {
        return vip;
    }

    public void setVip(boolean vip) {
        this.vip = vip;
    }
}
