package model;

import java.util.Date;

public class Mundo {
    
    private Empleado e;
    private Cliente c;
    
    public Mundo(){
        e = new Empleado("Juan", 1000000.0);
        c = new Cliente("Carlos", new Date(), true);
    }

    public Empleado getE() {
        return e;
    }

    public void setE(Empleado e) {
        this.e = e;
    }

    public Cliente getC() {
        return c;
    }

    public void setC(Cliente c) {
        this.c = c;
    }
}
