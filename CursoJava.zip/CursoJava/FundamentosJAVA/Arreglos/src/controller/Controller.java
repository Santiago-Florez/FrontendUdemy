package controller;

public class Controller {
    
    public Controller(){
        funcionar();
    }
    
    public void funcionar(){
        //se crean la matriz como 3 renglones y 2 columnas
        int edades[][] = new int[3][2];
        //se le da un valor al elemento en la posicion [0]
        edades[0][0] = 52;
        edades[0][1] = 700;
        edades[1][0] = 10;
        edades[1][1] = 112;
        edades[2][0] = 23;
        edades[2][1] = 102;
        for (int ren = 0; ren < edades.length; ren++){
            for(int col = 0; col < edades[ren].length; col++){
                System.out.println("|"+edades[ren][col]+" "+edades[ren][++col]+"|");
            }
        }
        
        String frutas[][] = {{"Naranjas","Limones"},{"Fresa", "Manzanas"}};
        verMatriz(frutas);
        
        Persona personas[][]= new Persona[3][2];
        personas[0][0] = new Persona("Carlos");
        personas[0][1] = new Persona("Juan");
        verMatriz(personas);
    }
    
    public void verMatriz(Object matriz[][]){
        for(int ren = 0; ren < matriz.length; ren++){
            for(int col = 0; col < matriz[ren].length; col++){
                System.out.println("|"+matriz[ren][col]+" "+matriz[ren][++col]+"|");
            }
        }
    }
}