package controller;

import javax.swing.JOptionPane;

/**
 *
 * @author Santiago Flórez
 */
class Controller {
    
    public Controller(){
        funcionar();
    }
    
    public void funcionar(){
        int x = 10;
        JOptionPane.showMessageDialog(null, "x = " + x);
        cambioValor(x);
    }
    
    public void cambioValor(int arg1){
        JOptionPane.showMessageDialog(null, "arg1 = " + arg1);
    }
}
