/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Santiago Flórez
 */
class Controller {

    public Controller() {
        //hagaMientras();
        //mientras();
        para();
    }

    public void hagaMientras() {
        int i = 0;
        do {
            System.out.println("i = " + i);
            i++;
        } while (i < 5);
    }

    public void mientras() {
        int i = 0;
        while (i <= 3) {
            System.out.println("i = " + i);
            i++;
        }
    }
    
    public void para(){
        for(int i = 0; i <= 12; i++){
            for(int j = 0; j <= 60; j++){
                System.out.println(i + ": " + j);
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException ex) {
                    Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
}
