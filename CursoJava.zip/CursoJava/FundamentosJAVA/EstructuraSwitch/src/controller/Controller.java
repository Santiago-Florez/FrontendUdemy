/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.util.Scanner;

/**
 *
 * @author Santiago Flórez
 */
class Controller {

    //Switch se evalua a partir de casos (menu)
    Scanner leer;
    private int mes;

    public Controller() {
        leer = new Scanner(System.in);
        mes = 0;
        //funcionar();
        funcionar2();
    }

    public void funcionar() {
        System.out.println("¿En qué mes estamos?");
        System.out.println("Ingrese numero del mes:");
        mes = leer.nextInt();
        switch (mes) {
            case 1:
            case 2:
            case 3:
                System.out.println("Estamos en los primeros 3 meses");
                break;
            case 4:
            case 5:
            case 6:
                System.out.println("Estamos en los siguientes 3 meses");
                break;
            case 7:
            case 8:
            case 9:
                System.out.println("Estamos en los penultimos 3 meses");
                break;
            case 10:
            case 11:
            case 12:
                System.out.println("Estamos en los ultimos 3 meses");
                break;
            //se ejecuta si no pasa ningun case
            default:
                System.out.println("Mes mo encontrado");
        }
    }

    public void funcionar2() {
        int numero = 0;
        System.out.println("Ingrese su nota:");
        numero = leer.nextInt();
        if (numero == 9 || numero == 10) {
            System.out.println("Su nota es A");
        } else if (numero == 8 && numero < 9) {
            System.out.println("Su nota es B");
        } else if (numero == 7 && numero < 8) {
            System.out.println("Su nota es C");
        } else if (numero == 6 && numero < 7) {
            System.out.println("Su nota es D");
        } else if (numero >= 0 && numero < 6) {
            System.out.println("Su nota es F");
        }else {
            System.out.println("Valor desconocido");
        }
    }
}
