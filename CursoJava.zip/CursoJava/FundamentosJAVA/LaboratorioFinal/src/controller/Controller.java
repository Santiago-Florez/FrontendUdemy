package controller;

import model.MundoPC;
import view.Ventana;

class Controller {

    private MundoPC mPC;
    private Ventana v;
    
    public Controller(){
        v = new Ventana();
        v.mostrarInfo("!!BIENVENIDO¡¡ a MundoPC");
        String nombrePC = v.pedirDatosSTR("Ingrese nombre de la marca del PC");
        String monitor = v.pedirDatosSTR("Ingrese la marca del monitor para su PC");
        int tam = v.pedirDatoINT("Ingrese el tamaño del monitor para su PC");
        String tecladoTE = v.pedirDatosSTR("Ingrese el tipo de entrada para el taclado para su PC");
        String tecladoM = v.pedirDatosSTR("Ingrese la marca del teclado para su PC");
        String ratonTE = v.pedirDatosSTR("Ingrese el tipo de entrada para el raton para su PC");
        String ratonM = v.pedirDatosSTR("Ingrese la marca del raton para su PC");
        mPC = new MundoPC(nombrePC,monitor,tam,tecladoTE,tecladoM,ratonTE,ratonM);
        mPC.getO().agregarComputadora(mPC.getC());
        v.mostrarInfo(mPC.getO().mostrarOrden());
    }
    
}
