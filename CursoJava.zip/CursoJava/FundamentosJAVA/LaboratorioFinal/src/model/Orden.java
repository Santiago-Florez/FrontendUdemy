package model;

public class Orden {

    private final int idOrden;
    private Computadora computadoras[];
    private static int contOrdenes;
    private int contComputadoras;
    private final static int maxComputadoras = 10;

    public Orden() {
        this.idOrden = ++Orden.contOrdenes;
        this.computadoras = new Computadora[Orden.maxComputadoras];
        this.contComputadoras = 0;
    }

    public void agregarComputadora(Computadora computadora) {
        if (this.contComputadoras < this.maxComputadoras) {
            this.computadoras[this.contComputadoras++] = computadora;
        } else {
            System.out.println("Has superado el limite");
        }
    }

    public String mostrarOrden() {
        String dato = "Orden# " + this.idOrden  + "\n";
        dato += "Productos:\n";
        for (int i = 0; i < this.contComputadoras; i++) {
            dato += this.computadoras[i];
        }
        return dato;
    }

    public Computadora[] getComputadoras() {
        return computadoras;
    }

    public void setComputadoras(Computadora[] computadoras) {
        this.computadoras = computadoras;
    }

    public int getContComputadoras() {
        return contComputadoras;
    }

    public void setContComputadoras(int contComputadoras) {
        this.contComputadoras = contComputadoras;
    }
}
