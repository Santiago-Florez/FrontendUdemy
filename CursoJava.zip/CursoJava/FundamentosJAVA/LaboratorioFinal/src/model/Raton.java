package model;

public class Raton extends DispositivoEntrada{
    
    private final int idRaton;
    private static int contRaton;

    public Raton(String tipoEntrada, String marca) {
        super(tipoEntrada, marca);
        this.idRaton = ++Raton.contRaton;
    }   

    @Override
    public String toString() {
        return "Raton " + "idRaton=" + idRaton + ", contRaton=" + contRaton + ' ';
    }
}
