package model;

public class MundoPC {
    
    private Monitor janus;
    private Teclado reDragon;
    private Raton logiTech;
    private Orden o;
    private Computadora c;
    
    public MundoPC(String nombre, String monitor, int tamanio, String tecladoTE, String tecladoM, String ratonTE, String ratonM){
        this.janus = new Monitor(monitor, tamanio);
        this.reDragon = new Teclado(tecladoTE, tecladoM);
        this.logiTech = new Raton(ratonTE, ratonM);
        this.c = new Computadora(nombre, this.janus, this.reDragon, this.logiTech);
        this.o = new Orden();
    }

    public Monitor getJanus() {
        return janus;
    }

    public void setJanus(Monitor janus) {
        this.janus = janus;
    }

    public Teclado getReDragon() {
        return reDragon;
    }

    public void setReDragon(Teclado reDragon) {
        this.reDragon = reDragon;
    }

    public Raton getLogiTech() {
        return logiTech;
    }

    public void setLogiTech(Raton logiTech) {
        this.logiTech = logiTech;
    }

    public Orden getO() {
        return o;
    }

    public void setO(Orden o) {
        this.o = o;
    }

    public Computadora getC() {
        return c;
    }

    public void setC(Computadora c) {
        this.c = c;
    }
}
