package view;

import javax.swing.JOptionPane;

public class Ventana {
    
    public void mostrarInfo(String mensaje){
        JOptionPane.showMessageDialog(null, mensaje);
    }
    
    public String pedirDatosSTR(String mensaje){
        String dato = JOptionPane.showInputDialog(null, mensaje);
        return dato;
    }
    
    public int pedirDatoINT(String mensaje){
        String dato = JOptionPane.showInputDialog(null, mensaje);
        int datoINT = Integer.parseInt(dato);
        return datoINT;
    }
}
