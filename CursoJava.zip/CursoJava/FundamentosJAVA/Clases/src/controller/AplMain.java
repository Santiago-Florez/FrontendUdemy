package controller;

public class AplMain {

    public static void main(String[] args) {
        // TODO code application logic here
        Controller c = new Controller();
    }
    
}
