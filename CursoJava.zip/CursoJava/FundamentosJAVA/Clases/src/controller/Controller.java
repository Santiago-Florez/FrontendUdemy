package controller;

import model.Persona;
import view.Vista;

/**
 *
 * @author Santiago Flórez
 */
public class Controller{
    //crear una instancia de una clase (crear un objeto)
    private Persona p;
    private Vista v;
    
    public Controller(){
        p = new Persona();
        v = new Vista();
        funcionar();
    }
    
    public void funcionar(){
        p.setNombre(v.leerInformacionString());
        p.setEdad(v.leerInformacionInt());
        v.mostrarInformacion(p.mostrarInformacion(p.getNombre(), p.getEdad()));
    }
}
