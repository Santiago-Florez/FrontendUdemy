/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import javax.swing.JOptionPane;

/**
 *
 * @author Santiago Flórez
 */
public class Vista {
    
    public Vista(){
        
    }
    
    public void mostrarInformacion(String mensaje){
        JOptionPane.showMessageDialog(null, mensaje);
    }
    
    public String leerInformacionString(){
        String nombre = JOptionPane.showInputDialog("Ingrese su nombre:");
        return nombre;
    }
    
    public int leerInformacionInt(){
        String edad = JOptionPane.showInputDialog("Ingrese su edad:");
        int edadN = Integer.parseInt(edad);
        return edadN;
    }    
}
