package model;
//Clase perona 
//Una clase es una plantilla donde se crean metodos que son funciones y atributos

//que son acciones que realiza la clase
public class Persona {
    //Se declaran los atributos
    private String nombre;
    private int edad;
    
    public Persona(){
        nombre = "";
        edad = 0;
    }
    //metodo que al ser llamado debe resivir 3 parametros
    public String mostrarInformacion(String nombre, int edad){
        //la palabra this hace referencia al atributo
        nombre = this.nombre;
        edad = this.edad;
        return "Mi nombre es: " + nombre + "\nMi edad es: " + edad;   
    }
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }
}
