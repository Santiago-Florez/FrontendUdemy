package controller;

public final class Controller {
    
    public final int B = 1;
    
    public Controller(){
       metodo(); 
    }
    
    public final void metodo(){
        final int n = 10;//su valor ya se podra modificar mas adelante
        System.out.println(n);
    }
}
