package Controlador;

/**
 *
 * @author Santiago Flórez
 */
class Controller {
    
    public Controller(){
        funcionar();
    }
    
    public void funcionar(){
        /**
         * Las variables se usan para guardar datos que se usan en el codigo.
         * Estos valores pueden cambiar en la ejecucion del codigo.
         * Se crean con la estructura:
         *  tipoVariable nombrevariable = valor;
         * Existen varios tipos de variables como int(Enteros), double(decimal),
         * String(texto), etc.
         */
        //Crear variable int: valores numericos enteros
        int numEntero = 12;
        System.out.println("Primer valor entero: " + numEntero);
        //Crear variable double: valores numericos decimales
        double numDecimal = 12.4;
        System.out.println("Primer valor decimal: " + numDecimal);
        //crear variable String: cadenas de texto
        String texto = "Aqui va un texto";
        System.out.println("Primer valor de texto: " + texto);
        /**
         * Modificar valores en variables
         * solo se debe poner el nombreVariable = nuevoDato;
         */
        numEntero = 13;
        System.out.println("Segundo valor entero: " + numEntero);
        
        numDecimal = 13.2;
        System.out.println("Segundo valor decimal: " + numDecimal);
        
        texto = "Segundo Texto";
        System.out.println("Segundo valor de texto: " + texto);
        
        /**
         * Segunda forma de declarar variables sin necesidad de poner el tipo 
         * se pone var nombreVariable = valor;
         * Java ya sabe de que tipo es por el valor del dato
         */
        
        var numEntero2 = 2;
        System.out.println("Variable declarada con var: " + numEntero2);
    }
}