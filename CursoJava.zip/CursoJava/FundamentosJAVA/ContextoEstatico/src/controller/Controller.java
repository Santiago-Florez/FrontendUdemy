package controller;

public class Controller {
    
    private int idPersona;
    private String nombre;
    //la palabra static hace que el atributo se asocie a la clase Controller
    private static int contPersona;
    
    public Controller(String nombre){
        this.nombre = nombre;
        //el valor numerico de este atributo va a aumentar por cada vez que se cree un objeto de la clase
        Controller.contPersona++;
        //si se le quitara la palabra static esta no cambia cuando se crea un nuevo objeto de la clase
        this.idPersona = Controller.contPersona;
    }
    
    //GETTERS & SETTERS
    public int getIdPersona() {
        return idPersona;
    }

    public void setIdPersona(int idPersona) {
        this.idPersona = idPersona;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public static int getContPersona() {
        return contPersona;
    }

    public static void setContPersona(int contPersona) {
        Controller.contPersona = contPersona;
    }

    //TOSTRING()
    @Override
    public String toString() {
        return "Controller{" + "idPersona=" + idPersona + ", nombre=" + nombre + '}';
    }   
}
