package controller;

public class AplMain {
   
   public static void main(String[] args) {
        // TODO code application logic here
        Controller c = new Controller("Juan");
        System.out.println("c = " + c);
        Controller c1 = new Controller("Oscar");
        System.out.println("c1 = " + c1);
    }
    
}
