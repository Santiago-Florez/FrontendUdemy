/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

public class Controller {
    
    public Controller(){
        /**
         * Concatenar es la union de elementos en este caso variables de texto
         * se usa el simbolo +
         * se pueden concatenar cualquier tipo de variable, pero si es int o 
         * double lo que hara es sumar los valores numericos
         */
        String texto1 = "Buenos";
        String texto2 = "dias";
        String unir = texto1 + " " + texto2;
        System.out.println(unir);
        
        //Union de valores numericos
        int num1 = 2;
        int num2 = 3;
        int unionNum = num1 + num2;
        System.out.println(unionNum); //va a sumar los numero, mas no unirlos
        //para poder unirlos se realiza de las siguientes formas
        //opcion 1 crear variable String
        String unionNum2 = num1 + " " + num2;
        System.out.println("Opcion 1 creando variable str: " + unionNum2);
        //Opcion 2 directamente desde el sysout
        System.out.println("Opcion 2 desde sysout: " + num1 + " " + num2);
        //En el siguiente ejemplo si se pone primero un string ya no hay
        //necesidad de hacer num1 + " " + num2 pues lo lee como str
        System.out.println("" + num1 + num2);
        //Si se escribe syout(""+ (num1 + num2)); aqui si va a sumar nu1 y num2
        //por el parentesis donde se puso num1 y num2
        //Convertir str a int o a double
        int num = Integer.parseInt("23");
        System.out.println("De str a int " + num);
        double numD = Double.parseDouble("23");
        System.out.println("De str a double " + numD);
        //convertir int o double a str
        String text = String.valueOf(23);
        System.out.println("De int a str " + text);
        //Imprimir solo siertas letras de un str
        char txt = "Hola Mundo".charAt(0);
        System.out.println("Devolver un caracter de un texto " + txt);
        
    }
}
