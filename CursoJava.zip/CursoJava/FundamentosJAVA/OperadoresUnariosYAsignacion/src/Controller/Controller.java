package Controller;

class Controller {

    public Controller() {
        //Unarios();
        //Asignacion();
    }

    public void Unarios() {
        int a = 3;
        int b = -a;//cambia el signo al valor de a
        int c = b - 3;//se hace una operacion aritmetica
        System.out.println("a = " + a);
        System.out.println("b = " + b);
        System.out.println("c = " + c);

        boolean v = true;//crea la vcariable booleana con el valor true
        boolean f = !v;//cambia el valor de true a false al aplicar "!"
        System.out.println("v = " + v);
        System.out.println("f = " + f);

        boolean f2 = false;
        boolean v2 = !f2;
        System.out.println("f2 = " + f2);
        System.out.println("v2 = " + v2);
        
        System.out.println("INCREMENTOS");
        //incremento
        //preincremento
        int e = 3;
        int r = ++e;//primero incrementa el valor de "e" y lo asigna a "e" y a "r"
        System.out.println("e = " + e);
        System.out.println("r = " + r);
        int w = 3;   
        int y = w++;//asigna el valor inicial de "w" a "y" y luego incrementa el valor de "w"
        System.out.println("w = " + w);
        System.out.println("y = " + y);
    }
}