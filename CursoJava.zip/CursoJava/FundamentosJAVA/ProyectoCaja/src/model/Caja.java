package model;

public class Caja {
    private double ancho;
    private double alto;
    private double profundo;
    
    public Caja(double ancho, double alto, double profundo){
        this.ancho = ancho;
        this.alto = alto;
        this.profundo = profundo;
    }
    
    public Caja(double ancho, double alto){
        this.ancho = ancho;
        this.alto = alto;
    }
        
    public double calcularVolumen(){
        double volumen = this.ancho * this.alto * this.profundo;
        return volumen;
    }
    
    public double calcularArea(){
        double area = this.ancho * this.alto;
        return area;
    }

    public double getAncho() {
        return ancho;
    }

    public void setAncho(double ancho) {
        this.ancho = ancho;
    }

    public double getAlto() {
        return alto;
    }

    public void setAlto(double alto) {
        this.alto = alto;
    }

    public double getProfundo() {
        return profundo;
    }

    public void setProfundo(double profundo) {
        this.profundo = profundo;
    }
}
