package controller;

import java.util.InputMismatchException;
import java.util.Scanner;
import model.Caja;

public class Controller {

    private Caja caja;
    private Caja cajaA;
    private Scanner leer;

    public Controller() {
        leer = new Scanner(System.in);
        caja = new Caja(0, 0, 0);
        cajaA = new Caja(0, 0);
        funcionar();
    }

    public void funcionar() {
        System.out.println("CALCULO DE VOLUMEN O AREA DE CAJA");
        int option = 0;
        do{
            System.out.println("¿Qué desea hallar?\n" + "1. VOLUMEN\n" 
                                        + "2. AREA\n" + "3. SALIR");
            option = leer.nextInt();
            switch(option){
                case 1:
                    try{
                        System.out.println("VOLUMEN");
                        System.out.println("Ingrese ALTURA de la CAJA:");
                        double altura = (int) leer.nextDouble();
                        caja.setAlto(altura);
                        System.out.println("Ingrese ANCHO de la CAJA");
                        double ancho = (int) leer.nextDouble();
                        caja.setAncho(ancho);
                        System.out.println("Ingrese FONDO de la CAJA");
                        double fondo = (int) leer.nextDouble();
                        caja.setProfundo(fondo);
                        System.out.println(caja.calcularVolumen());
                    }catch(InputMismatchException e){
                        System.out.println("ES UN NÚMERO PAI!!");
                    }
                    break;
                case 2:
                    try{
                        System.out.println("AREA");
                        System.out.println("Ingrese ALTURA de la CAJA:");
                        double altura = (int) leer.nextDouble();
                        cajaA.setAlto(altura);
                        System.out.println("Ingrese ANCHO de la CAJA");
                        double ancho = (int) leer.nextDouble();
                        cajaA.setAncho(ancho);
                        System.out.println(cajaA.calcularArea());
                    }catch(InputMismatchException e){
                        System.out.println("ES UN NÚMERO PAI!!");
                    }
                    break;
                case 3:
                    System.out.println("GRACIAS POR USAR EL PROGRAMA :)");
                    break;
                default:
                    System.out.println("SOLO DEBE ELGIR 1, 2 o 3");
                    break;      
            }
        }while(option <= 2);   
    }
}
