/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlle;

import java.util.Scanner;

/**
 *
 * @author Santiago Flórez
 */
class Controller {

    Scanner leer;
    private int num1;
    private int num2;

    public Controller() {
        leer = new Scanner(System.in);
        num1 = 0;
        num2 = 0;
        funcionar();
    }

    //Operador Ternario sirve para devolver valores dependiendo de una condicion
    //estructura es condicion ? <valor si es verdadero> : <valor si es falso>
    public void funcionar() {
        System.out.println("CALCULAR EL NUMERO MAYOR");
        System.out.println("Ingrese primer numero:");
        num1 = leer.nextInt();
        System.out.println("Ingrese segundo numero:");
        num2 = leer.nextInt();
        String resul = (num1 > num2) ? "El mayor es: " + num1 : "El mayor es: " + num2;
        System.out.println(resul);
    }
}
