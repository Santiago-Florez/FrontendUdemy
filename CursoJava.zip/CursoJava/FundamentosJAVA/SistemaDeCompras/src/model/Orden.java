package model;

public class Orden {

    private int idOrden;
    private Producto productos[];
    private static int contOrdenes;
    private int contProductos;
    private final static int MAX_PRODUCTOS = 10;

    public Orden() {
        this.idOrden = ++contOrdenes;
        this.productos = new Producto[MAX_PRODUCTOS];
    }

    public void agregarProducto(Producto producto) {
        if (this.contProductos < MAX_PRODUCTOS) {
            this.productos[this.contProductos++] = producto;
        }
    }

    public double calcularTotal() {
        double total = 0.0;
        for (int i = 0; i < this.contProductos; i++) {
            total += this.productos[i].getPrecio();
        }
        return total;
    }

    public String mostrarOrden() {
        String orden = "";
        orden += "Orden #: " + this.idOrden;
        orden += "\nLos productos escogidos son:\n";
        for (int i = 0; i < this.contProductos; i++) {
            orden += this.productos[i] + "\n";
        }
        orden += "Total de la orden: " + this.calcularTotal();
        return orden;
    }

    public int getIdOrden() {
        return idOrden;
    }

    public void setIdOrden(int idOrden) {
        this.idOrden = idOrden;
    }

    public Producto[] getProductos() {
        return productos;
    }

    public void setProductos(Producto[] productos) {
        this.productos = productos;
    }

    public int getContProductos() {
        return contProductos;
    }

    public void setContProductos(int contProductos) {
        this.contProductos = contProductos;
    }
    
    public static int getContOrdenes() {
        return contOrdenes;
    }

    public static void setContOrdenes(int aContOrdenes) {
        contOrdenes = aContOrdenes;
    }
}
