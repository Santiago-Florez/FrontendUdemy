package model;

public class Mundo {

    private Producto p;
    private Producto p2;
    private Orden o;
    private Orden o2;

    public Mundo() {
        p = new Producto("Camisa Polo", 90000);
        p2 = new Producto("Jean", 50000);
        o = new Orden();
        o2 = new Orden();
    }

    public String combinacion() {
        String lista = "";
        String lista2 = "";
        o.agregarProducto(p);
        o.agregarProducto(p2);
        o2.agregarProducto(p);
        lista += o.mostrarOrden();
        lista2 += o2.mostrarOrden();
        return lista + "\n" +  lista2;
    }

    public Producto getP() {
        return p;
    }

    public void setP(Producto p) {
        this.p = p;
    }

    public Orden getO() {
        return o;
    }

    public void setO(Orden o) {
        this.o = o;
    }
}
