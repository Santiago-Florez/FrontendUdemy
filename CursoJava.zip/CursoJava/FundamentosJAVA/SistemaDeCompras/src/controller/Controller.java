package controller;

import model.Mundo;
import view.Ventana;

public class Controller {
    
    private Mundo m;
    private Ventana v;
    
    public Controller(){
        m = new Mundo();
        v = new Ventana();
        funcionar();
    }
    
    public void funcionar(){
        v.mostrarInfo(m.combinacion());
    }
}
