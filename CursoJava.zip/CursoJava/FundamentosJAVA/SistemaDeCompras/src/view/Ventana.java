package view;

import javax.swing.JOptionPane;

public class Ventana {
    
    public Ventana(){
    }
    
    public void mostrarInfo(String mensaje){
        JOptionPane.showMessageDialog(null, mensaje);
    }
    
    public String ingresarProducto(String mensaje){
        String producto = JOptionPane.showInputDialog(mensaje);
        return producto;
    }
}
